<?php
$kennesia_telegram_id = "6139929513";
$kennesia_token_bot = "7010518397:AAEhv5CuhTumSc6CRH-BpckAd6ifI7m2vVY";
?>
