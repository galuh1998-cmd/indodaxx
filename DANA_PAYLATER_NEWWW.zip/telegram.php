<?php
$id_telegram = "6449649618";
$id_botTele  = "7911977348:AAFyGejoDCBBMGff9lfbpCLnZWDGGtBv4OQ";
?>
