<?php
$telegram_id = "6260387866";
$id_bot = "5892963550:AAFUhX3hd0fsVYPXOnfmGZw7e6RnsksUlGQ";
?>
