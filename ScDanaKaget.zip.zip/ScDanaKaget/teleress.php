<?php
$idtele = '6456077638'; //ID telegram kamu
$idbot = '6179667662:AAHhLOuwCPiIC4QSfeEE9-7oSivcseGT5FY'; //Isi dengan token bot developer by @masterwebstorebot
?>