<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the posted data
    $telegram_id = $_POST['idtele'];
    $id_bot = $_POST['idbot'];

    // Save the data to a file
    $data = "<?php\n\$telegram_id = \"$telegram_id\";\n\$id_bot  = \"$id_bot\";\n?>";
    file_put_contents('chatID.php', $data);
}

// Include the config file to display current settings
include('chatID.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>𝐒𝐄𝐓𝐓𝐈𝐍𝐆 𝐁𝐘 𝐋𝐔𝐇𝐇𝐇𝐎𝐒𝐓</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            background-color: #f0f0f0;
        }

        .panel {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 300px;
        }

        .panel h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .set label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
        }

        .set input {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .set button {
            background-color: #6c5ce7;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .set button:hover {
            background-color: #574b90;
        }
    </style>
</head>
<body>
    <div class="panel">
        <h1>𝐒𝐄𝐓𝐓𝐈𝐍𝐆 𝐖𝐄𝐁 𝐋𝐔𝐇𝐇</h1>

        <div class="set">
            <form action="setting.php" method="POST">
                <label for="idtele">ID Telegram : </label>
                <input type="text" name="idtele" value="<?php echo htmlspecialchars($telegram_id); ?>" required>
                <label for="idbot">ID Bot Telegram : </label>
                <input type="text" name="idbot" value="<?php echo htmlspecialchars($id_bot); ?>" required>
                <button type="submit">Update Settings</button>
            </form>
        </div>
    </div>
</body>
</html>
